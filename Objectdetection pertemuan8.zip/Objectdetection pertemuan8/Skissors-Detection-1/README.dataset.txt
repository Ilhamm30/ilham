# Skissors Detection > 2026-04-22 1:15pm
https://universe.roboflow.com/kel3-workspace-b88zs/skissors-detection-pifuk

Provided by a Roboflow user
License: CC BY 4.0

